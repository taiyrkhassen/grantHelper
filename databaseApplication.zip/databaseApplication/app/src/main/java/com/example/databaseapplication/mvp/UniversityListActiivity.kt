package com.example.databaseapplication.mvp

class UniversityListActiivity{



}
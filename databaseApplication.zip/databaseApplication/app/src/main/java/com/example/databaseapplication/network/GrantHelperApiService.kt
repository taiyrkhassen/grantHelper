package com.example.databaseapplication.network

interface GrantHelperApiService{
    companion object{
        val BASE_URL:String = ""
    }


}